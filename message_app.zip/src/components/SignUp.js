import React from 'react'
import '../styles/SignUp'

function SignUp() {
    return (
        <div>
            <h1>sifn upppppppp</h1>
        </div>
    )
}

export default SignUp
